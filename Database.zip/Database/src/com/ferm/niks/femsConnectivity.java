package com.ferm.niks;


import java.sql.*;

public class femsConnectivity 
{

	
	
	public static void main(String []args)
	{
    try
   {
	  //for loading Driver
	  
	Class.forName("com.mysql.cj.jdbc.Driver");
	  
	// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	  
	  //2.Connection with database
   Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikhil","root","root");
	
	//3.Statement
	
//	if(con.isClosed())
//	{
//		System.out.print("Connection is not closed");
//	}
//		else 
//	{
//		System.out.println("connection is created........");
//	}
   
   
  //   for creating the table 
   //String q="create table niksFertilizers(Id int,NameOfClient varchar(60),Location varchar(50))";
   //Statement stmt=con.createStatement();
   //stmt.executeUpdate(q);
   //System.out.println("table is inserted...........");
   
   // for inserting the values in the table
   
   String q="insert into niksFertilizers(Id,NameOfClient,Location) values(?,?,?)";
   PreparedStatement pstmt=con.prepareStatement(q);
   pstmt.setInt(1,30461);
   pstmt.setString(2,"ritesh patan");
   pstmt.setString(3,"Bengol");
   
   pstmt.executeUpdate();
   
   System.out.println("rows are inserted..........");
   
	con.close();
	
   }catch(Exception e)
    {
	 e.printStackTrace();
    }

  
	    
}
}



